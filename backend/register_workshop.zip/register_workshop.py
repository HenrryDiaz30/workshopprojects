import json
import boto3
from datetime import datetime, timezone

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('workshops')

def lambda_handler(event, context):
    try:
        workshop_id = event.get("pathParameters", {}).get("id")

        body = json.loads(event.get("body", "{}"))
        user_id = body.get("userId")
        user_name = body.get("userName", "")
        user_email = body.get("userEmail", "")

        if not workshop_id or not user_id:
            return {
                "statusCode": 400,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({"message": "id del taller y userId son obligatorios"})
            }

        now = datetime.now(timezone.utc).isoformat()

        item = {
            "PK": f"WORKSHOP#{workshop_id}",
            "SK": f"REG#USER#{user_id}",
            "userId": user_id,
            "userName": user_name,
            "userEmail": user_email,
            "registeredAt": now,
            "status": "registered"
        }

        table.put_item(Item=item)

        return {
            "statusCode": 201,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "message": "Estudiante registrado correctamente",
                "item": item
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"message": str(e)})
        }